<script>
function sayHello(){
    alert('thank you');
}
sayHello('are you sure');
    
    
    function getSum(a,b){
        return (a+b);
    }
    var sum = getSum(4,5);
    console.log(sum);

    
    function saySomething(){
    let i = 1;
    do{
        document.write('<br> this is a do while'+i);
        i = i +1;
        if (i == 3){
        break;
      }
    }
    
    while(i < 5);
}
saySomething();
    
    
    
    
var person = [];
person ['name'] = 'Jon';
person ['age'] = 34;
person ['height'] = '6.7ft';
document.write(' <br>'+ person.name+' '+ person.age+ '<br> <br>'); // print array out

function objectNest(){
    var cars = [{
        type:"Blockchain",
        year:2015
    },
       { type:"XRP",
         year: 2015
       },
            
        { type:"Ethererum",
         year:2014
         
       }
        
    
    ];
    
    for( let a = 0; a < cars.length; a++ ){
        document.write('<li>'+cars[a].type+' - '+cars[a].year+'</li>');
    }
    
}
objectNest();

var e = 1;
while (e<=5){
    document.write("<br> This is a standalone while loop <br/> ");
    e++;
}


</script>





<?php

$cookie_name = "username";
$cookie_val ="devuser";

Setcookie($cookie_name,$cookie_val, time(
)+3600);

if(!isset ($_COOKIE[$cookie_name])){
    echo ' cookie - m'.$cookie_name.' is not set';
    
}
    else {
        echo 'Cookie - '.$cookie_name.' is set <br>
        
browse-happy-notice';
            echo ' <br> cookie value - '.$cookie_val;
        
    }
    
    
    ?>
<script>


    
var a = 23;
var y = 10;
var z = 10;

if(a < y && z == 10){
    document.write('<br>'+a +' is less than '+y +'and z is 10');
}
else if(a==y){
    document.write('<br>'+a +'  is equal to '+ y);
}
else{
    document.write( '<br>'+a +' more than or equal to'+ y);
    }
</script>